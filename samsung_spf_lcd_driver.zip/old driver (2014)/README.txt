===================================================================
 Windows LibUSB driver for Samsung SPF Series Digital Photo Frames
===================================================================

This driver was created to let our software (AIDA64) use Samsung
SPF Series DPF (Digital Photo Frame) displays as an external LCD
screen.  Using AIDA64 you can put various sensor readings and
other system values on the LCD.

Learn more about AIDA64 at:

http://www.aida64.com/

This Windows driver is based on LibUSB-Win32 v1.2.6.0 drivers.

The kernel driver files (libusb0.sys) are all digitally signed and
so can be used under 64-bit Windows Vista, Windows 7, Windows 8,
and Windows 8.1.

Tested on Samsung SPF-75H and Samsung 800P DPF.

If you've got any questions or concerns about using this driver,
you can reach us at:

http://forums.aida64.com/

[-] FinalWire Team [-]

- August 17, 2014
